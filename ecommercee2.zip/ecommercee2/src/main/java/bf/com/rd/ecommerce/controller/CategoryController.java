package bf.com.rd.ecommerce.controller;

import bf.com.rd.ecommerce.model.Category;
import bf.com.rd.ecommerce.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.List;
@RestController
public class CategoryController {

    @Autowired
    private CategoryRepository categoryRepository;

    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping("/category")
    public Category save(@RequestBody Category category) {
        return categoryRepository.save(category);
    }

    @GetMapping("/category/{idCategoria}")
    public Category findById(@PathVariable("idCategoria") Long idDaCategoria) {
        return categoryRepository.findById(idDaCategoria).get();
    }

    @GetMapping("/category")
    public List<Category> findCategoryById(@PathParam("id") Long id) {
        return (List<Category>) categoryRepository.findById(id).get();
    }

    @DeleteMapping("/category/{id}")
    public void deleteById(@PathVariable("id") Long id) {
        categoryRepository.deleteById(id);
    }

    @PutMapping("/category")
    public ResponseEntity<Category> alterar(@RequestBody Category category) {
        Category categoryEntity = categoryRepository.getOne(category.getId_category());
        categoryEntity.setDescription(category.getDescription());
        Category categoryAtualiza = categoryRepository.save(categoryEntity);
        return ResponseEntity.ok().body(categoryAtualiza);
    }

    @PatchMapping("/category")
    public ResponseEntity<Category> alterarCamposEspecificos(@RequestBody Category category) {
        Category categoryEntity = categoryRepository.getOne(category.getId_category());
        categoryEntity.setDescription(category.getDescription());
        Category categoryAtualiza = categoryRepository.save(categoryEntity);
        return ResponseEntity.ok().body(categoryAtualiza);


    }
}