package bf.com.rd.ecommerce;

import bf.com.rd.ecommerce.model.User;

public class Teste {

    public static void main(String[] args) {

    }
}

