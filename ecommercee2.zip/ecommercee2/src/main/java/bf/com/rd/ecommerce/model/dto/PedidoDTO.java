package bf.com.rd.ecommerce.model.dto;

import bf.com.rd.ecommerce.model.ItemPedido;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PedidoDTO {

    private Integer codPedido;
    private Date dtPedido;
    private Integer idCliente;
    private BigDecimal vlPedido;
    private BigDecimal vlFrete;
    private String dsFormaPagto;
    private List<ItemPedido> itensPedido;

    private List<ItemPedidoDTO> itens;

}
