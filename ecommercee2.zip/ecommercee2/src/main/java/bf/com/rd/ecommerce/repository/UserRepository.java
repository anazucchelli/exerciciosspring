package bf.com.rd.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import bf.com.rd.ecommerce.model.User;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
//    List<User> findByFirstName (String firstName);
//    List<User> findByLastName(String lastName);
//    List<User> findByAge (Integer age);


    @Override
    List<User> findAllById(Iterable<Long> iterable);

}
