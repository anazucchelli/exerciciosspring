package bf.com.rd.ecommerce.repository;

import bf.com.rd.ecommerce.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    public List<Product> findByIdProductAndDescription(Long codigo, String description);

    List<Product> findByDescription(String description);
}


