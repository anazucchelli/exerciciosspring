package bf.com.rd.ecommerce.service;

import bf.com.rd.ecommerce.model.ItemPedido;
import bf.com.rd.ecommerce.model.Pedido;
import bf.com.rd.ecommerce.model.dto.ItemPedidoDTO;
import bf.com.rd.ecommerce.model.dto.PedidoDTO;
import bf.com.rd.ecommerce.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service("PedidoService")
public class PedidoService {

    @Autowired
    PedidoRepository pedidoRepository;

    //metodo para salvar pedidoDTO
    public ResponseEntity salvar(PedidoDTO pedidoDTO){
        //TODO incluir validações
        if(pedidoDTO == null || pedidoDTO.getIdCliente() == null )
            return ResponseEntity.badRequest().body(new Exception("Cliente não informado"));

        if (pedidoDTO.getItens() == null)
            return ResponseEntity.badRequest().body(new Exception("Pedido não contem item"));

        Pedido pedidoEntity  = new Pedido();
        pedidoEntity.setDtPedido(pedidoDTO.getDtPedido());
        pedidoEntity.setIdCliente(pedidoDTO.getIdCliente());
        pedidoEntity.setVlPedido(pedidoDTO.getVlPedido());
        pedidoEntity.setVlFrete(pedidoDTO.getVlFrete());
        pedidoEntity.setDsFormaPagto(pedidoDTO.getDsFormaPagto());
        pedidoEntity.setDtAtualizacao(new Date());

        List<ItemPedido> listaItens = new ArrayList<>();
        for(ItemPedidoDTO itPedido : pedidoDTO.getItens()){
            ItemPedido it = new ItemPedido();
            it.setVlProduto(itPedido.getVlProduto());
            it.setQuantidade(itPedido.getQuantidade());
            it.setCodProduto(itPedido.getCodProduto());
            it.setVlFrete(itPedido.getVlFrete());

            listaItens.add(it);
        }
        pedidoEntity.setItensPedido(listaItens);
        pedidoEntity =  pedidoRepository.save(pedidoEntity);

        pedidoDTO.setIdCliente(pedidoEntity.getCodPedido());
        return ResponseEntity.ok().body(pedidoDTO);
    }


}
