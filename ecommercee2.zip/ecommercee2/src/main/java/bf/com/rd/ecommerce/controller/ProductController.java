package bf.com.rd.ecommerce.controller;

import bf.com.rd.ecommerce.model.Product;
import bf.com.rd.ecommerce.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping("/product")
    public Product save(@RequestBody Product product) {
        return productRepository.save(product);
    }

    @GetMapping("/product/buscaPorId/{idProduct}")
        public Product buscarporId(@PathVariable("idProduct") Long idDoProduct){
            return productRepository.findById(idDoProduct).get();
        }

    @GetMapping("/product/buscarPorDescricao/{description}")
        public List<Product> findProductById(@PathParam("description") String description){
            return productRepository.findByDescription(description);
        }

    @DeleteMapping("/product/{id}")
        public void excluirProduto(@PathVariable("id") Long id){
            productRepository.deleteById(id);
        }

        @PutMapping("/product")
        public Product alterar(@RequestBody Product product){
            Product productEntity = productRepository.getOne(product.getIdProduct());

            productEntity.setDescription(product.getDescription());
            productEntity.setVlProduct(product.getVlProduct());
            productEntity.setCategory(product.getCategory());

            return productRepository.save(productEntity);
        }

        @GetMapping("product")
        public ResponseEntity<List<Product>>buscarPorId(@PathParam("id")Long id,
                                                        @PathParam("description") String description){
        List<Product> product = new ArrayList<>();

            if(id != null && description != null)
              product = productRepository.findByIdProductAndDescription(id,description);
            else if(id != null)
               product.add(productRepository.findById(id).get());
            else if(description != null)
                product = productRepository.findByDescription(description);

            if(product != null && product.size()>0)
                return ResponseEntity.ok().body(product);
            else
                return ResponseEntity.badRequest().build();
        }

//        @PatchMapping("/product")
//        public ResponseEntity alterarCamposEspecificos(@RequestBody Product product){
//            Product productEntity = productRepository.getOne(product.getId_product());
//
//            productEntity.setDescription(product.getDescription());
//            productEntity.setVlProduct(product.getVlProduct());
//            productEntity.setCategory(product.getCategory());
//
//            Category productAtualiza = productEntity.save(productEntity);
//            return ResponseEntity.ok().body(productAtualiza);
//        }
    }


