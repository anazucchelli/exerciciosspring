package bf.com.rd.ecommerce.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tb_user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_user;
    @NotNull
    @Column(name = "email_user",length=100)
    private String email;
    @NotNull
    @Column(name = "password_user",length=45)
    private String password;
    @NotNull
    @Column(name = "name_user",length=80)
    private String userName;
    @NotNull
    @Column(name = "cpf_user",length=11)
    private String cpf;
    @NotNull
    @Column(name = "birthday_user")
    private Date birthday;

}
